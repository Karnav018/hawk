const G = '#070B16', ACC = '#5B8CFF', OK = '#5FD39B', TXT = '#E6E8EC', DIM = '#8A94A8';
const SERIF = "'Instrument Serif', Georgia, serif", UI = 'Archivo, sans-serif', MONO = "'Martian Mono', monospace";
const lerp = (a, b, k) => a + (b - a) * k;
const prog = (T, a, b, e) => e(clamp((T - a) / (b - a), 0, 1));
// the three motion helpers
const MOTION = {
  enter: (T, a, d = 0.7) => prog(T, a, a + d, Easing.easeOutCubic),
  move: (T, a, d = 1) => prog(T, a, a + d, Easing.easeInOutCubic),
  pop: (T, a, d = 0.6) => prog(T, a, a + d, Easing.easeOutBack),
};
const win = (T, a, b, fi = 0.6, fo = 0.5) => MOTION.enter(T, a, fi) * (1 - MOTION.enter(T, b - fo, fo));
const abs = (x, y, extra = {}) => ({ position: 'absolute', left: x, top: y, ...extra });

function Orb({ x, y, size, spin = 0, glow = 1, opacity = 1 }) {
  return (
    <div style={abs(x - size / 2, y - size / 2, { width: size, height: size, opacity })}>
      <div style={{ position: 'absolute', inset: '-55%', borderRadius: '50%', background: `radial-gradient(circle, rgba(91,140,255,${0.5 * glow}) 0%, rgba(91,140,255,${0.14 * glow}) 38%, rgba(91,140,255,0) 68%)` }} />
      <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', overflow: 'hidden', boxShadow: 'inset 0 -24px 60px rgba(4,8,20,.45)' }}>
        <img src="assets/orb_sphere.png" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        <img src="orb-emission.png" style={{ position: 'absolute', inset: '-30%', width: '160%', height: '160%', objectFit: 'cover', mixBlendMode: 'screen', opacity: 0.55, filter: 'blur(3px) saturate(1.3)', transform: `rotate(${spin}deg)` }} />
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 34% 26%, rgba(255,255,255,.55), rgba(255,255,255,0) 46%)' }} />
      </div>
    </div>
  );
}

const FILES = [
  ['SCREENSHOT', 'Casa Lumen house guide', 'Photos', 190, 170, -7], ['PDF', 'Lease_final_v3.pdf', 'Downloads', 560, 120, 4],
  ['LINK', 'That ramen place Sam sent', 'WhatsApp', 1330, 140, -3], ['VOICE NOTE', 'Idea — rooftop launch', 'Recorder', 1650, 250, 6],
  ['PHOTO', 'Parking level P3', 'Photos', 1560, 560, -5], ['PDF', 'Boarding pass LIS→BER', 'Mail', 1400, 820, 3],
  ['SCREENSHOT', 'Dentist — confirm Tues', 'Messages', 960, 880, -2], ['LINK', 'Figma — pricing v2', 'Slack', 470, 850, 5],
  ['NOTE', 'Gift ideas for Mom', 'Notes', 120, 620, -4], ['PHOTO', 'Whiteboard, Q3 plan', 'Drive', 300, 420, 7],
  ['VOICE NOTE', 'Call with the landlord', 'Recorder', 1700, 870, -6], ['SCREENSHOT', 'Router label', 'Photos', 820, 90, 2],
];
function Files({ T, C }) {
  return FILES.map(([type, title, src, x, y, rot], i) => {
    const inK = MOTION.pop(T, 0.2 + i * 0.22, 0.7);
    const fly = MOTION.move(T, C.Reveal + 0.15 + i * 0.05, 1.1);
    const dim = 1 - 0.45 * MOTION.enter(T, C.Search + 0.2, 0.8);
    const shake = T > C.Search + 3 && T < C.Search + 3.5 ? Math.sin(T * 60 + i) * 5 : 0;
    const dx = Math.sin(T * 0.6 + i) * 8, dy = Math.cos(T * 0.5 + i * 1.7) * 8;
    const px = lerp(x + dx + shake, 960 - 120, fly), py = lerp(y + dy, 450 - 70, fly);
    const sc = lerp(inK, 0.08, fly), op = Math.min(1, inK * 1.4) * dim * (1 - clamp((fly - 0.8) / 0.2, 0, 1));
    return (
      <div key={i} style={abs(px, py, { width: 240, padding: '18px 20px', borderRadius: 18, background: '#111a31', border: '1px solid rgba(230,232,236,.12)', transform: `rotate(${lerp(rot, 0, fly)}deg) scale(${sc})`, opacity: op, display: 'flex', flexDirection: 'column', gap: 10 })}>
        <span style={{ fontFamily: MONO, fontSize: 12, letterSpacing: '.1em', color: ACC }}>{type}</span>
        <span style={{ fontFamily: UI, fontSize: 21, color: TXT, lineHeight: 1.2 }}>{title}</span>
        <span style={{ fontFamily: UI, fontSize: 15, color: DIM }}>in {src}</span>
      </div>
    );
  });
}

function Search({ T, C }) {
  const q = 'the wifi code from the airbnb';
  const n = Math.floor(clamp((T - C.Search - 0.8) / 1.6, 0, 1) * q.length);
  const op = win(T, C.Search, C.Reveal + 0.4);
  const miss = MOTION.enter(T, C.Search + 2.8, 0.4);
  return (
    <div style={abs(960 - 380, 470, { width: 760, opacity: op, transform: `translateY(${(1 - MOTION.enter(T, C.Search, 0.7)) * 30}px)`, display: 'flex', flexDirection: 'column', gap: 18, alignItems: 'center' })}>
      <div style={{ width: '100%', height: 88, borderRadius: 44, background: '#16213d', border: '1.5px solid rgba(230,232,236,.22)', display: 'flex', alignItems: 'center', padding: '0 34px', gap: 18, boxShadow: '0 30px 80px rgba(0,0,0,.5)' }}>
        <div style={{ width: 22, height: 22, borderRadius: '50%', border: `3px solid ${DIM}` }} />
        <span style={{ fontFamily: UI, fontSize: 32, color: TXT }}>{q.slice(0, n)}<span style={{ opacity: Math.floor(T * 2.5) % 2 ? 1 : 0, color: ACC }}>|</span></span>
      </div>
      <span style={{ fontFamily: UI, fontSize: 26, color: '#ff8a7a', opacity: miss }}>No results — in Photos, Drive, Mail or Notes</span>
    </div>
  );
}

function StepCopy({ T, from, to, n, title, body }) {
  const k = win(T, from, to, 0.8, 0.5);
  return (
    <div style={abs(200, 330, { width: 680, opacity: k, transform: `translateY(${(1 - MOTION.enter(T, from, 0.8)) * 40}px)`, display: 'flex', flexDirection: 'column', gap: 26 })}>
      <span style={{ fontFamily: MONO, fontSize: 18, letterSpacing: '.14em', color: ACC }}>{n}</span>
      <span style={{ fontFamily: SERIF, fontSize: 108, lineHeight: 0.98, color: TXT, letterSpacing: '-.02em' }}>{title}</span>
      <span style={{ fontFamily: UI, fontSize: 30, lineHeight: 1.45, color: DIM, textWrap: 'pretty' }}>{body}</span>
    </div>
  );
}

function CaptureScreen({ T, C }) {
  const s0 = C.Capture;
  const sheet = MOTION.enter(T, s0 + 1.5, 0.6) * (1 - MOTION.move(T, s0 + 3.6, 0.5));
  const tap = clamp((T - s0 - 3.0) / 0.6, 0, 1);
  const shrink = MOTION.move(T, s0 + 3.8, 0.8);
  const toast = MOTION.pop(T, s0 + 4.4, 0.6);
  const apps = [['Messages', '#3fbf6a'], ['Mail', '#3a7bf0'], ['Notes', '#e8c23a'], ['Knowra', null]];
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#f3f1ec' }}>
      <div style={{ position: 'absolute', left: 24, right: 24, top: 90, transformOrigin: '50% 0', transform: `scale(${lerp(1, 0.5, shrink)}) translateY(${shrink * 180}px)`, borderRadius: lerp(0, 26, shrink), background: '#fff', padding: 28, display: 'flex', flexDirection: 'column', gap: 16, boxShadow: `0 20px 50px rgba(0,0,0,${0.25 * shrink})` }}>
        <span style={{ fontFamily: SERIF, fontSize: 38, color: '#1a1a1a' }}>Casa Lumen</span>
        <span style={{ fontFamily: UI, fontSize: 17, color: '#6b6b6b' }}>House guide · check-in from 3pm</span>
        <div style={{ borderRadius: 16, background: '#f3f1ec', padding: 20, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontFamily: MONO, fontSize: 12, letterSpacing: '.1em', color: '#8a8a8a' }}>WI-FI</span>
          <span style={{ fontFamily: UI, fontSize: 22, color: '#1a1a1a' }}>lumen_guest</span>
          <span style={{ fontFamily: MONO, fontSize: 30, color: '#1a1a1a' }}>0417</span>
        </div>
        {[92, 100, 76, 88].map((w, i) => <div key={i} style={{ height: 10, width: `${w}%`, borderRadius: 5, background: '#e7e4dd' }} />)}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 330, background: '#fff', borderRadius: '30px 30px 0 0', transform: `translateY(${(1 - sheet) * 340}px)`, boxShadow: '0 -20px 50px rgba(0,0,0,.15)', padding: '26px 28px', display: 'flex', flexDirection: 'column', gap: 26 }}>
        <span style={{ fontFamily: UI, fontSize: 20, fontWeight: 600, color: '#1a1a1a', alignSelf: 'center' }}>Share screenshot</span>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          {apps.map(([name, c], i) => (
            <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, width: 76, position: 'relative' }}>
              {c ? <div style={{ width: 68, height: 68, borderRadius: 18, background: c }} /> :
                <div style={{ width: 68, height: 68, borderRadius: 18, background: G, position: 'relative', transform: `scale(${1 - 0.1 * Math.sin(Math.PI * tap)})` }}><Orb x={34} y={34} size={46} spin={T * 30} glow={0.6} /></div>}
              {!c && tap > 0 && tap < 1 ? <div style={abs(38 - 60 * tap, 34 - 60 * tap, { width: 120 * tap, height: 120 * tap, borderRadius: '50%', border: `3px solid ${ACC}`, opacity: 1 - tap })} /> : null}
              <span style={{ fontFamily: UI, fontSize: 15, color: '#333' }}>{name}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ position: 'absolute', left: 30, right: 30, top: 70, height: 84, borderRadius: 24, background: G, display: 'flex', alignItems: 'center', gap: 16, padding: '0 22px', opacity: Math.min(1, toast), transform: `translateY(${(1 - toast) * -40}px)` }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: OK, display: 'flex', alignItems: 'center', justifyContent: 'center', color: G, fontFamily: UI, fontWeight: 700, fontSize: 20 }}>✓</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <span style={{ fontFamily: UI, fontSize: 19, color: TXT }}>Saved to Knowra</span>
          <span style={{ fontFamily: MONO, fontSize: 12, color: DIM }}>INDEXED · TEXT · 1 CODE</span>
        </div>
      </div>
    </div>
  );
}

function AskScreen({ T, C }) {
  const s0 = C.Ask;
  const q = 'What was the Wi-Fi code at the Airbnb?';
  const n = Math.floor(clamp((T - s0 - 1.0) / 2.2, 0, 1) * q.length);
  const up = MOTION.move(T, s0 + 3.6, 0.8);
  const ans = MOTION.pop(T, s0 + 4.1, 0.7);
  const listening = 1 - up;
  const oy = lerp(300, 150, up), os = lerp(210, 110, up);
  return (
    <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse 90% 60% at 50% 30%, #15254f, ${G} 75%)` }}>
      {[0, 1, 2].map((i) => {
        const a = ((T * 0.7 + i / 3) % 1);
        const r = os / 2 + a * 150;
        return <div key={i} style={abs(200 - r, oy - r, { width: r * 2, height: r * 2, borderRadius: '50%', border: `2px solid rgba(143,172,255,${0.4 * (1 - a) * listening})` })} />;
      })}
      <Orb x={200} y={oy} size={os} spin={T * 40} glow={1} />
      <span style={abs(0, lerp(440, 250, up), { width: 400, textAlign: 'center', fontFamily: MONO, fontSize: 13, letterSpacing: '.14em', color: ACC, opacity: listening })}>LISTENING…</span>
      <div style={abs(36, lerp(480, 240, up), { width: 328, fontFamily: SERIF, fontSize: 34, lineHeight: 1.15, color: TXT, textAlign: 'center' })}>{n ? `“${q.slice(0, n)}${n === q.length ? '”' : ''}` : ''}</div>
      <div style={abs(24, 400, { width: 352, borderRadius: 26, background: '#111a31', border: '1px solid rgba(230,232,236,.14)', padding: 24, display: 'flex', flexDirection: 'column', gap: 12, opacity: Math.min(1, ans), transform: `translateY(${(1 - ans) * 60}px)` })}>
        <span style={{ fontFamily: MONO, fontSize: 12, letterSpacing: '.12em', color: DIM }}>CASA LUMEN · LUMEN_GUEST</span>
        <span style={{ fontFamily: MONO, fontSize: 66, color: TXT, letterSpacing: '.04em' }}>0417</span>
        <span style={{ fontFamily: UI, fontSize: 18, color: DIM, lineHeight: 1.4 }}>The Wi-Fi password from the Casa Lumen house guide.</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 6, padding: 10, borderRadius: 14, background: 'rgba(91,140,255,.12)' }}>
          <div style={{ width: 42, height: 54, borderRadius: 8, background: '#f3f1ec' }} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <span style={{ fontFamily: UI, fontSize: 16, color: TXT }}>Screenshot</span>
            <span style={{ fontFamily: MONO, fontSize: 11, color: DIM }}>SAVED AUG 12 · PHOTOS</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function Phone({ T, C }) {
  const inK = MOTION.enter(T, C.Capture - 0.7, 1.1);
  const outK = MOTION.move(T, C.Understand - 0.3, 0.8);
  const x = lerp(2200, 1180, inK), y = 120 + outK * 1000;
  const askK = MOTION.enter(T, C.Ask, 0.5);
  return (
    <div style={abs(x, y, { width: 400, height: 840, borderRadius: 62, background: '#05070d', padding: 12, boxShadow: '0 60px 120px rgba(0,0,0,.6), 0 0 0 2px #1f273a', opacity: 1 - outK })}>
      <div style={{ position: 'relative', width: 376, height: 816, borderRadius: 50, overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, width: 400, left: -12 }}><CaptureScreen T={T} C={C} /></div>
        <div style={{ position: 'absolute', inset: 0, width: 400, left: -12, opacity: askK }}><AskScreen T={T} C={C} /></div>
        <div style={abs(138, 14, { width: 100, height: 30, borderRadius: 16, background: '#000' })} />
      </div>
    </div>
  );
}

function Insights({ T, C }) {
  const s0 = C.Understand;
  const op = win(T, s0 + 0.2, C.Close + 0.2, 0.8, 0.5);
  const rows = [
    ['Duplicates across Drive and Photos', 142, 'files · 3.2 GB', 0.62, DIM],
    ['Untouched for two years', 1208, 'files', 0.9, DIM],
    ['Still matters — you asked for these', 86, 'memories', 0.34, OK],
  ];
  return (
    <div style={abs(360, 190, { width: 1200, opacity: op, display: 'flex', flexDirection: 'column', gap: 54 })}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 22, transform: `translateY(${(1 - MOTION.enter(T, s0 + 0.2, 0.8)) * 40}px)` }}>
        <span style={{ fontFamily: MONO, fontSize: 18, letterSpacing: '.14em', color: ACC }}>03 — UNDERSTAND</span>
        <span style={{ fontFamily: SERIF, fontSize: 100, lineHeight: 1, color: TXT, letterSpacing: '-.02em' }}>Know what's worth keeping.</span>
      </div>
      {rows.map(([label, val, unit, w, c], i) => {
        const k = MOTION.move(T, s0 + 1.2 + i * 0.45, 1.4);
        return (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 14, opacity: MOTION.enter(T, s0 + 1.0 + i * 0.45, 0.5) }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontFamily: UI, fontSize: 30, color: TXT }}>{label}</span>
              <span style={{ fontFamily: MONO, fontSize: 34, color: c === OK ? OK : TXT }}>{Math.round(val * k).toLocaleString('en-US')} <span style={{ fontSize: 18, color: DIM }}>{unit}</span></span>
            </div>
            <div style={{ height: 10, borderRadius: 5, background: 'rgba(230,232,236,.08)' }}>
              <div style={{ height: '100%', width: `${w * k * 100}%`, borderRadius: 5, background: c === OK ? OK : ACC, opacity: c === OK ? 1 : 0.7 }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Piece() {
  const { T, CUES: C, authoredTotal: END } = useComposition();
  // orb: born at Reveal, dives into the phone at Capture, reborn at Close; out before loop seam
  const born = MOTION.pop(T, C.Reveal + 0.9, 0.8), dive = MOTION.move(T, C.Capture - 0.2, 0.9);
  const close = MOTION.pop(T, C.Close + 0.1, 0.9), fin = 1 - MOTION.enter(T, END - 0.9, 0.8);
  const inCap = T < C.Close;
  const ox = inCap ? lerp(960, 1380, dive) : 960, oy = inCap ? lerp(450, 540, dive) : 400;
  const osz = inCap ? 280 * born * lerp(1, 0.2, dive) : 230 * close;
  const oop = inCap ? 1 - dive : fin;
  const absorb = T > C.Reveal && T < C.Reveal + 1.6 ? 1 + 0.4 * Math.sin((T - C.Reveal) * 6) : 1;
  const tag = win(T, C.Reveal + 1.5, C.Capture - 0.1, 0.8, 0.5);
  const hook = win(T, 0.6, C.Search + 0.3, 0.8, 0.6);
  const zoom = MOTION.move(T, C.Ask + 4.0, 1.0) * (1 - MOTION.move(T, C.Understand - 1.2, 0.9));
  const endK = MOTION.enter(T, C.Close + 0.8, 0.8) * fin;
  const ctaK = MOTION.pop(T, C.Close + 1.6, 0.7);
  return (
    <div style={{ position: 'absolute', inset: 0, background: G, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 70% 60% at 50% 45%, rgba(40,70,160,.35), rgba(7,11,22,0) 70%)' }} />
      <div style={{ position: 'absolute', inset: 0, transformOrigin: '1380px 540px', transform: `scale(${1 + 0.28 * zoom})` }}>
        <Files T={T} C={C} />
        <div style={abs(0, 470, { width: 1920, textAlign: 'center', opacity: hook, fontFamily: SERIF, fontSize: 92, color: TXT, letterSpacing: '-.02em' })}>You saved it somewhere.</div>
        <Search T={T} C={C} />
        {osz > 1 ? <Orb x={ox} y={oy} size={osz * absorb} spin={T * 36} glow={1.1} opacity={oop} /> : null}
        <div style={abs(0, 690, { width: 1920, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, opacity: tag, transform: `translateY(${(1 - MOTION.enter(T, C.Reveal + 1.5, 0.8)) * 30}px)` })}>
          <span style={{ fontFamily: MONO, fontSize: 18, letterSpacing: '.18em', color: ACC }}>KNOWRA</span>
          <span style={{ fontFamily: SERIF, fontSize: 104, color: TXT, letterSpacing: '-.02em' }}>Your memory, extended.</span>
        </div>
        <StepCopy T={T} from={C.Capture + 0.6} to={C.Ask + 0.2} n="01 — CAPTURE" title="Save anything." body="Screenshots, PDFs, links and voice notes — from any app, in one tap." />
        <StepCopy T={T} from={C.Ask + 0.4} to={C.Understand} n="02 — ASK" title="Ask in your own words." body="Knowra finds the answer, and shows you exactly where it came from." />
        <Phone T={T} C={C} />
        <Insights T={T} C={C} />
      </div>
      <div style={abs(0, 580, { width: 1920, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22, opacity: endK })}>
        <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 128, color: TXT, letterSpacing: '-.03em' }}>Knowra</span>
        <span style={{ fontFamily: UI, fontSize: 32, color: DIM }}>Capture everything. Remember anything.</span>
        <div style={{ marginTop: 22, padding: '22px 46px', borderRadius: 50, background: ACC, color: G, fontFamily: UI, fontWeight: 600, fontSize: 28, transform: `scale(${ctaK})`, opacity: Math.min(1, ctaK) }}>Install Knowra</div>
      </div>
    </div>
  );
}

function LaunchVideo() {
  return (
    <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={G}>
      <Piece />
    </CompositionStage>
  );
}
window.LaunchVideo = LaunchVideo;

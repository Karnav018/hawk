const cl = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp = (a, b, k) => a + (b - a) * k;
const eo = (x) => 1 - Math.pow(1 - x, 3), ei = (x) => x * x * x;
const eio = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const bk = (x) => { const c = 1.70158; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };
// the three motion helpers
const MOTION = {
  enter: (t, a, d = 0.8) => eo(cl((t - a) / d)),
  move: (t, a, d = 1) => eio(cl((t - a) / d)),
  pop: (t, a, d = 0.7) => bk(cl((t - a) / d)),
};
const win = (t, a, b, fi = 0.8, fo = 0.8) => MOTION.enter(t, a, fi) * (1 - ei(cl((t - (b - fo)) / fo)));
const rnd = (i, s = 1) => { const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return v - Math.floor(v); };
const A = (x, y, o = {}) => ({ position: 'absolute', left: x, top: y, ...o });
const FULL = { position: 'absolute', inset: 0 };
const NAVY = '#0b1030', CREAM = '#f6efe2', INK = '#231c3a';
const SERIF = "'Instrument Serif', Georgia, serif", UI = 'Archivo, sans-serif', MONO = "'Martian Mono', monospace";

function Stars({ T }) {
  return Array.from({ length: 110 }, (_, i) => {
    const s = 1.5 + rnd(i, 2) * 2.5;
    return <div key={i} style={A(rnd(i) * 1920, rnd(i, 3) * 1080, { width: s, height: s, borderRadius: '50%', background: CREAM, opacity: 0.25 + 0.35 * (0.5 + 0.5 * Math.sin(T * (0.6 + rnd(i, 4)) + i)) })} />;
  });
}

function Cap({ t, a, b, text, y = 870, size = 60, em }) {
  const k = win(t, a, b, 0.9, 0.7);
  if (k <= 0) return null;
  return (
    <div style={A(160, y, { width: 1600, textAlign: 'center', opacity: k, transform: `translateY(${(1 - MOTION.enter(t, a, 0.9)) * 24}px)`, fontFamily: SERIF, fontSize: size, lineHeight: 1.12, color: CREAM, letterSpacing: '-.01em', textShadow: '0 4px 30px rgba(5,8,25,.85)', textWrap: 'balance' })}>
      {em ? <span style={{ fontStyle: 'italic', color: '#ffd27a' }}>{em} </span> : null}{text}
    </div>
  );
}

function Mem({ kind, x, y, s = 1, rot = 0, op = 1, blur = 0, ghost = false }) {
  if (op <= 0.01) return null;
  const line = ghost ? '3px dashed rgba(246,239,226,.55)' : `3px solid ${INK}`;
  const fill = (c) => (ghost ? 'transparent' : c);
  const wrap = A(x, y, { transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${s})`, opacity: op, filter: blur > 0.2 ? `blur(${blur}px)` : undefined, boxShadow: ghost ? 'none' : '0 18px 40px rgba(0,0,0,.35)', border: line });
  if (kind === 'photo') return (
    <div style={{ ...wrap, width: 220, height: 250, borderRadius: 10, background: fill('#fffaf0'), padding: 14 }}>
      <div style={{ position: 'relative', height: 172, borderRadius: 6, overflow: 'hidden', background: ghost ? 'transparent' : 'linear-gradient(#8fd3f4, #fbe3b8)', border: ghost ? line : 'none' }}>
        {!ghost && <>
          <div style={A(132, 22, { width: 38, height: 38, borderRadius: '50%', background: '#ffd27a' })} />
          <div style={A(-20, 112, { width: 260, height: 120, borderRadius: '50%', background: '#5bb59a' })} />
          <div style={A(0, 140, { width: 200, height: 40, background: '#4a8fc9', opacity: 0.8 })} />
          <div style={A(70, 88, { width: 20, height: 20, borderRadius: '50%', background: '#f0c9a0', border: `2px solid ${INK}` })} />
          <div style={A(64, 106, { width: 32, height: 34, borderRadius: '14px 14px 4px 4px', background: '#c85c7a', border: `2px solid ${INK}` })} />
          <div style={A(104, 98, { width: 15, height: 15, borderRadius: '50%', background: '#f0c9a0', border: `2px solid ${INK}` })} />
          <div style={A(100, 112, { width: 24, height: 26, borderRadius: '12px 12px 4px 4px', background: '#ffb347', border: `2px solid ${INK}` })} />
        </>}
      </div>
      <div style={{ marginTop: 16, height: 8, width: '60%', borderRadius: 4, background: ghost ? 'transparent' : '#e3d8c4' }} />
    </div>
  );
  if (kind === 'doc') return (
    <div style={{ ...wrap, width: 190, height: 240, borderRadius: '8px 40px 8px 8px', background: fill('#fbf7ee'), padding: '28px 22px', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ height: 14, width: '70%', borderRadius: 4, background: ghost ? 'transparent' : '#5b7cfa' }} />
      {[100, 88, 95, 70, 92, 60].map((w, i) => <div key={i} style={{ height: 8, width: `${w}%`, borderRadius: 4, background: ghost ? 'transparent' : '#dcd2c0', border: ghost ? '1px dashed rgba(246,239,226,.35)' : 'none' }} />)}
    </div>
  );
  if (kind === 'voice') return (
    <div style={{ ...wrap, width: 290, height: 96, borderRadius: 48, background: fill('#ff8f6b'), display: 'flex', alignItems: 'center', gap: 6, padding: '0 22px' }}>
      <div style={{ width: 52, height: 52, borderRadius: '50%', background: fill(CREAM), border: ghost ? line : 'none', marginRight: 10, flex: 'none' }} />
      {[18, 34, 50, 28, 44, 60, 30, 46, 22, 38, 16].map((h, i) => <div key={i} style={{ width: 8, height: h, borderRadius: 4, background: ghost ? 'rgba(246,239,226,.5)' : INK }} />)}
    </div>
  );
  if (kind === 'folder') return (
    <div style={{ ...wrap, width: 240, height: 170, borderRadius: '8px 22px 12px 12px', background: fill('#ffc857') }}>
      <div style={A(-3, -34, { width: 110, height: 34, borderRadius: '12px 12px 0 0', background: fill('#f4b53c'), border: line, borderBottom: 'none' })} />
      <div style={A(24, 40, { width: 150, height: 12, borderRadius: 6, background: ghost ? 'transparent' : 'rgba(35,28,58,.25)' })} />
    </div>
  );
  return (
    <div style={{ ...wrap, width: 170, height: 170, borderRadius: 6, background: fill('#ffe27a'), padding: 22, display: 'flex', flexDirection: 'column', gap: 12 }}>
      {[90, 70, 80].map((w, i) => <div key={i} style={{ height: 8, width: `${w}%`, borderRadius: 4, background: ghost ? 'transparent' : 'rgba(35,28,58,.3)' }} />)}
    </div>
  );
}

function Hawk({ x, y, s = 1, flap = 0, rot = 0, op = 1 }) {
  const L = 60 * flap;
  const wing = `M14 -8 Q90 ${-40 - L * 0.5} 170 ${-18 - L} L182 ${-6 - L} L160 ${-1 - L * 0.9} L168 ${8 - L * 0.8} L146 ${10 - L * 0.7} L150 ${21 - L * 0.6} L126 ${18 - L * 0.5} Q70 ${32 - L * 0.2} 14 18 Z`;
  const cov = `M16 -2 Q80 ${-24 - L * 0.4} 132 ${-8 - L * 0.75} Q80 ${14 - L * 0.3} 16 12 Z`;
  return (
    <svg width="440" height="280" viewBox="-220 -140 440 280" style={A(x - 220, y - 140, { transform: `rotate(${rot}deg) scale(${s})`, opacity: op, overflow: 'visible' })}>
      <g stroke="#2a1a10" strokeWidth="3.5" strokeLinejoin="round">
        <path d="M-15 48 L15 48 L24 84 L0 92 L-24 84 Z" fill="#8b5a2b" />
        <path d={wing} fill="#7a5230" /><path d={wing} fill="#7a5230" transform="scale(-1,1)" />
        <path d={cov} fill="#a7713f" /><path d={cov} fill="#a7713f" transform="scale(-1,1)" />
        <ellipse cx="0" cy="10" rx="22" ry="46" fill="#6b4527" />
        <ellipse cx="0" cy="18" rx="13" ry="30" fill="#ecd6ab" strokeWidth="0" />
        <circle cx="0" cy="-34" r="19" fill="#6b4527" />
        <path d="M-12 -30 Q0 -20 12 -30 Q8 -18 0 -16 Q-8 -18 -12 -30 Z" fill="#ecd6ab" strokeWidth="0" />
        <path d="M-6 -29 L6 -29 L0 -15 Z" fill="#f2b53a" strokeWidth="2.5" />
        <circle cx="-8" cy="-38" r="5" fill="#f7c048" strokeWidth="2" /><circle cx="8" cy="-38" r="5" fill="#f7c048" strokeWidth="2" />
        <circle cx="-8" cy="-38" r="2" fill="#111" strokeWidth="0" /><circle cx="8" cy="-38" r="2" fill="#111" strokeWidth="0" />
      </g>
    </svg>
  );
}

function Orb({ x, y, size, spin = 0, glow = 1, op = 1 }) {
  if (size < 1 || op <= 0.01) return null;
  return (
    <div style={A(x - size / 2, y - size / 2, { width: size, height: size, opacity: op })}>
      <div style={{ position: 'absolute', inset: '-60%', borderRadius: '50%', background: `radial-gradient(circle, rgba(120,160,255,${0.5 * glow}) 0%, rgba(120,160,255,${0.14 * glow}) 38%, rgba(120,160,255,0) 68%)` }} />
      <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', overflow: 'hidden', boxShadow: 'inset 0 -24px 60px rgba(4,8,20,.45)' }}>
        <img src="assets/orb_sphere.png" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
        <img src="assets/orb_emission.png" style={{ position: 'absolute', inset: '-30%', width: '160%', height: '160%', objectFit: 'cover', mixBlendMode: 'screen', opacity: 0.55, filter: 'blur(3px)', transform: `rotate(${spin}deg)` }} />
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 34% 26%, rgba(255,255,255,.55), rgba(255,255,255,0) 46%)' }} />
      </div>
    </div>
  );
}

const KINDS = ['photo', 'doc', 'voice', 'folder', 'note', 'photo', 'doc', 'voice'];
function hill(base, a, seed) {
  let d = `M0 1080 L0 ${base}`;
  for (let x = 0; x <= 3840; x += 30) d += ` L${x} ${(base + a * Math.sin(6.283 * (2 * x / 1920 + seed)) + a * 0.45 * Math.sin(6.283 * (5 * x / 1920 + seed * 3))).toFixed(1)}`;
  return d + ' L3840 1080 Z';
}
const HILLS = [[640, 90, 0.1, '#6d4f8f', 30], [760, 70, 0.4, '#4b3a78', 70], [880, 50, 0.7, '#2c2552', 130]].map(([b, a, s, f, v]) => ({ d: hill(b, a, s), f, v }));

// 1 — memories drift into places we can no longer see
function Lost({ t }) {
  return (
    <div style={FULL}>
      <div style={{ ...FULL, background: 'radial-gradient(ellipse 60% 50% at 50% 48%, rgba(90,110,200,.25), rgba(11,16,48,0) 70%)' }} />
      {KINDS.map((k, i) => {
        const ang = (i / KINDS.length) * 6.283 + 0.4, a = 0.3 + i * 0.28;
        const r = 170 + Math.max(0, t - a) * 62;
        return <Mem key={i} kind={k} x={960 + Math.cos(ang) * r * 1.7} y={480 + Math.sin(ang) * r * 0.85} s={0.95 - t * 0.06} rot={Math.sin(t * 0.5 + i) * 8} blur={Math.max(0, (t - 3) * 1.4)} op={MOTION.enter(t, a, 0.9) * (1 - cl((t - 4.5) / 3.2) * 0.85)} />;
      })}
      {[0, 1, 2].map((i) => <div key={i} style={A(-300 + i * 700 + t * 30, 200 + i * 180, { width: 1100, height: 420, borderRadius: '50%', background: 'rgba(160,170,220,.08)', filter: 'blur(40px)' })} />)}
      <Cap t={t} a={1.2} b={8.2} text="We keep so much of our lives in places we can no longer see." />
    </div>
  );
}

// 2 — we remember, but not where
function Remember({ t }) {
  const ghostK = MOTION.move(t, 3.8, 1.2);
  const items = [['photo', -170, -20, -8], ['voice', 140, -80, 5], ['doc', 190, 70, 7], ['folder', -40, 110, -3]];
  return (
    <div style={FULL}>
      <div style={A(200, 110, { width: 150, height: 150, borderRadius: '50%', background: '#fbf0cf', boxShadow: '0 0 120px 30px rgba(251,240,207,.25)' })} />
      <div style={A(0, 960, { width: 1920, height: 120, background: '#171238' })} />
      <div style={A(470, 560, { width: 460, height: 420, borderRadius: '230px 230px 30px 30px', background: '#2b2350', border: `4px solid ${INK}`, boxShadow: '-6px -6px 0 rgba(251,240,207,.12) inset' })} />
      <div style={A(590, 380, { width: 220, height: 240, borderRadius: '50%', background: '#3a2f63', border: `4px solid ${INK}` })} />
      <div style={A(575, 360, { width: 250, height: 150, borderRadius: '125px 125px 60px 60px', background: '#1f1838' })} />
      {[[790, 330, 30], [850, 270, 46]].map(([x, y, s], i) => <div key={i} style={A(x, y, { width: s, height: s, borderRadius: '50%', background: 'rgba(246,239,226,.14)', border: '3px solid rgba(246,239,226,.5)', opacity: MOTION.enter(t, 0.4 + i * 0.25, 0.5) })} />)}
      <div style={A(900, 60, { width: 760, height: 460, transform: `scale(${MOTION.pop(t, 0.8, 0.8)})`, transformOrigin: '10% 90%' })}>
        {[[0, 140, 300], [170, 40, 340], [390, 60, 320], [520, 170, 260], [300, 200, 300], [90, 240, 260]].map(([x, y, s], i) => <div key={i} style={A(x, y, { width: s, height: s * 0.8, borderRadius: '50%', background: 'rgba(246,239,226,.12)', border: '3px solid rgba(246,239,226,.45)' })} />)}
        {items.map(([k, dx, dy, r], i) => {
          const drift = MOTION.move(t, 4.2 + i * 0.25, 2.2);
          return (
            <React.Fragment key={i}>
              <Mem kind={k} x={380 + dx + drift * (dx > 0 ? 700 : -900)} y={250 + dy - drift * 120} s={0.55 * (1 - drift * 0.4)} rot={r} op={MOTION.enter(t, 1.3 + i * 0.25) * (1 - ghostK)} blur={drift * 6} />
              <Mem kind={k} x={380 + dx} y={250 + dy} s={0.55} rot={r} ghost op={ghostK * (1 - MOTION.enter(t, 7, 0.8))} />
            </React.Fragment>
          );
        })}
        {[[250, 150], [480, 120], [370, 320]].map(([x, y], i) => {
          const k = MOTION.pop(t, 4.6 + i * 0.3, 0.6);
          return <span key={i} style={A(x, y - Math.abs(Math.sin(t * 3 + i)) * 14, { fontFamily: SERIF, fontSize: 90, color: '#ffd27a', opacity: cl(k), transform: `scale(${k})` })}>?</span>;
        })}
      </div>
      <Cap t={t} a={1.2} b={4.2} text="We remember these things." />
      <Cap t={t} a={4.4} b={8.2} text="We just don't always remember where they are." />
    </div>
  );
}

// 3 — dawn, Hawk is born
function Born({ t }) {
  const dawn = MOTION.move(t, 0, 5);
  const burst = Math.max(win(t, 0.8, 2.6, 0.3, 0.3), win(t, 5.2, 6.8, 0.3, 0.3));
  const flap = Math.sin(t * 8) * burst + Math.sin(t * 1.4) * 0.12;
  return (
    <div style={FULL}>
      <div style={{ ...FULL, background: 'linear-gradient(#2d2a6e 0%, #b8618a 55%, #ffb37a 88%)', opacity: dawn }} />
      <div style={A(860, lerp(900, 470, MOTION.move(t, 0.2, 6)), { width: 220, height: 220, borderRadius: '50%', background: '#ffd98a', boxShadow: '0 0 160px 60px rgba(255,210,130,.45)' })} />
      {HILLS.map((h, i) => (
        <svg key={i} width="3840" height="1080" style={A(-t * h.v, 0)}><path d={h.d} fill={h.f} stroke={INK} strokeWidth="4" /></svg>
      ))}
      <Hawk x={lerp(1500, 820, MOTION.move(t, 0, 9))} y={380 + Math.sin(t * 1.3) * 26} s={1.7 * MOTION.enter(t, 0, 1.4)} flap={flap} rot={Math.sin(t * 0.9) * 6} op={MOTION.enter(t, 0, 1)} />
      <Cap t={t} a={2.2} b={9.2} em="Hawk" text="was born from that feeling." size={72} />
    </div>
  );
}

// 4 — the hawk's eye, then the aerial search
function Vision({ t }) {
  const blink = 1 - Math.max(win(t, 1.4, 1.75, 0.15, 0.15), win(t, 3.6, 3.95, 0.15, 0.15));
  const zoom = ei(cl((t - 4.4) / 1.6));
  const aerial = MOTION.enter(t, 5.4, 0.8);
  const way = [[400, 300], [1500, 700], [700, 800], [1260, 420]];
  const p = cl((t - 6) / 2.2) * 3, seg = Math.min(2, Math.floor(p)), f = eio(p - seg);
  const rx = lerp(way[seg][0], way[seg + 1][0], f), ry = lerp(way[seg][1], way[seg + 1][1], f);
  const lock = MOTION.pop(t, 8.2, 0.5), photo = MOTION.pop(t, 8.6, 0.8);
  return (
    <div style={FULL}>
      <div style={{ ...FULL, opacity: 1 - aerial, transformOrigin: '960px 500px', transform: `scale(${1 + zoom * 16})`, background: 'radial-gradient(circle at 50% 46%, #9a6a3c, #5a3a20 70%)' }}>
        {Array.from({ length: 14 }, (_, i) => <div key={i} style={A(-200 + i * 170, 700 + (i % 2) * 60, { width: 260, height: 520, borderRadius: '50% 50% 40% 40%', background: i % 2 ? '#6b4527' : '#7a5230', border: `4px solid ${INK}`, transform: `rotate(${(i - 7) * 5}deg)` })} />)}
        <div style={A(560, 180, { width: 800, height: 150, borderRadius: '50%', background: '#3a2414', transform: 'rotate(-6deg)' })} />
        <div style={A(700, 240, { width: 520, height: 520, borderRadius: '50%', background: '#1a1008', border: `6px solid ${INK}`, overflow: 'hidden' })}>
          <div style={{ position: 'absolute', inset: 20, borderRadius: '50%', background: 'radial-gradient(circle, #ffd35a 20%, #e89420 70%, #9a5a10)', transform: `scaleY(${blink})` }}>
            <div style={A(240 - 100 - Math.sin(t) * 8, 240 - 100, { width: 200, height: 200, borderRadius: '50%', background: '#07060a', transform: `scale(${1 + zoom * 0.4})` })} />
            <div style={A(290, 110, { width: 70, height: 70, borderRadius: '50%', background: 'rgba(255,255,255,.9)' })} />
            <div style={A(250, 190, { width: 26, height: 26, borderRadius: '50%', background: 'rgba(255,255,255,.7)' })} />
          </div>
          <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: `${(1 - blink) * 55}%`, background: '#6b4527' }} />
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: `${(1 - blink) * 50}%`, background: '#6b4527' }} />
        </div>
      </div>
      {aerial > 0 && (
        <div style={{ ...FULL, opacity: aerial, background: '#142a2c', overflow: 'hidden' }}>
          {Array.from({ length: 16 }, (_, i) => <div key={i} style={A(rnd(i, 7) * 1920 - 200, rnd(i, 8) * 1080 - 150, { width: 400 + rnd(i, 9) * 300, height: 260 + rnd(i, 10) * 200, borderRadius: '42% 58% 50% 50%', background: ['#1d3a36', '#24443b', '#193230', '#2a4a40'][i % 4], border: '3px solid #0e1f20' })} />)}
          <svg width="1920" height="1080" style={FULL}><path d="M-50 900 C 400 700, 600 950, 900 650 S 1500 300, 1980 200" fill="none" stroke="#2f5f7a" strokeWidth="46" strokeLinecap="round" /></svg>
          {Array.from({ length: 70 }, (_, i) => <div key={i} style={A(rnd(i, 11) * 1920, rnd(i, 12) * 1080, { width: 6, height: 6, borderRadius: '50%', background: '#ffe9a8', boxShadow: '0 0 12px 4px rgba(255,220,140,.5)', opacity: 0.4 + 0.4 * Math.sin(t * 2 + i) })} />)}
          <div style={A(1260 - 10, 420 - 10, { width: 20, height: 20, borderRadius: '50%', background: '#ffe9a8', boxShadow: `0 0 ${20 + lock * 40}px ${8 + lock * 20}px rgba(255,220,140,.7)` })} />
          <div style={A(rx - 90, ry - 90, { width: 180, height: 180, borderRadius: '50%', border: '4px solid #ffd27a', transform: `scale(${1 - lock * 0.35})`, opacity: 1 - photo })}>
            {[0, 90, 180, 270].map((r) => <div key={r} style={A(86, -18, { width: 4, height: 30, background: '#ffd27a', transformOrigin: '2px 108px', transform: `rotate(${r}deg)` })} />)}
          </div>
          <Mem kind="photo" x={1260} y={420} s={photo * 1.3} rot={-4} op={cl(photo)} />
        </div>
      )}
      <Cap t={t} a={0.5} b={4.6} text="A hawk can see what is almost invisible from far away." />
      <Cap t={t} a={6.2} b={10.2} text="We wanted to bring that same vision to our digital memories." />
    </div>
  );
}

// 5 — your memories stay with you
function Private({ t }) {
  const b = MOTION.pop(t, 0.2, 1);
  return (
    <div style={FULL}>
      <div style={{ ...FULL, background: 'radial-gradient(ellipse 50% 50% at 50% 46%, rgba(255,190,120,.22), rgba(11,16,48,0) 70%)' }} />
      <div style={A(960 - 300, 470 - 300, { width: 600, height: 600, borderRadius: '50%', transform: `scale(${b})`, background: 'radial-gradient(circle at 40% 35%, rgba(255,230,190,.28), rgba(255,170,110,.1) 60%, rgba(255,170,110,.04))', border: '4px solid rgba(246,239,226,.55)', boxShadow: '0 0 90px rgba(255,190,120,.25)' })} />
      {['photo', 'doc', 'voice', 'folder', 'note'].map((k, i) => {
        const a = t * 0.45 + (i / 5) * 6.283;
        return <Mem key={i} kind={k} x={960 + Math.cos(a) * 170} y={470 + Math.sin(a) * 150} s={0.5 * b} rot={Math.sin(a) * 10} op={cl(b)} />;
      })}
      <div style={A(960 - 150, 770, { width: 300, padding: '14px 0', borderRadius: 40, background: 'rgba(246,239,226,.1)', border: '2px solid rgba(246,239,226,.35)', textAlign: 'center', fontFamily: MONO, fontSize: 18, letterSpacing: '.12em', color: CREAM, opacity: MOTION.enter(t, 1.2) })}>YOUR STORAGE</div>
      <Hawk x={lerp(-300, 2200, MOTION.move(t, 3, 5))} y={170 + Math.sin(t * 1.5) * 20} s={0.7} flap={Math.sin(t * 1.2) * 0.2} rot={4} />
      <Cap t={t} a={0.8} b={4.4} text="Your memories stay where they belong — with you." y={880} />
      <Cap t={t} a={4.6} b={8.2} text="Hawk simply helps you look across what you've kept." y={880} />
    </div>
  );
}

// 6 — you don't have to remember
function Words({ t }) {
  const rows = [['a filename.', 'IMG_20190714_1832.jpg'], ['a folder.', '/Backup/Old Phone/DCIM/2019'], ['exactly what you wrote.', '“grandma lake tahoe summr”']];
  const out = 1 - MOTION.enter(t, 6.2, 0.6);
  const big = MOTION.enter(t, 6.8, 1);
  return (
    <div style={FULL}>
      <div style={A(260, 170, { fontFamily: MONO, fontSize: 24, letterSpacing: '.14em', color: '#9aa3c9', opacity: MOTION.enter(t, 0.2) * out })}>YOU DON'T HAVE TO REMEMBER</div>
      {rows.map(([w, chip], i) => {
        const a = 0.5 + i * 1.8, k = MOTION.enter(t, a), s = MOTION.move(t, a + 1.1, 0.5);
        return (
          <div key={i} style={A(260, 260 + i * 190, { width: 1400, display: 'flex', alignItems: 'center', justifyContent: 'space-between', opacity: k * out, transform: `translateX(${(1 - k) * 40}px)` })}>
            <span style={{ fontFamily: SERIF, fontSize: 96, color: CREAM, letterSpacing: '-.02em' }}>{w}</span>
            <div style={{ position: 'relative', padding: '18px 28px', borderRadius: 14, background: '#1a2150', border: '3px solid #3a4480', fontFamily: MONO, fontSize: 26, color: '#c3c9e6', opacity: 1 - s * 0.5 }}>
              {chip}
              <div style={A(-10, 34, { height: 6, width: `calc(${s * 100}% + ${s * 20}px)`, borderRadius: 3, background: '#ff8f6b' })} />
            </div>
          </div>
        );
      })}
      <div style={A(0, 420, { width: 1920, textAlign: 'center', opacity: big, transform: `scale(${0.94 + 0.06 * big})`, fontFamily: SERIF, fontSize: 150, lineHeight: 1, color: CREAM, letterSpacing: '-.03em' })}>
        Just remember<br /><span style={{ fontStyle: 'italic', color: '#ffd27a' }}>what you remember.</span>
      </div>
    </div>
  );
}

// 7 — ask; the orb brings back the actual file
function Ask({ t }) {
  const q = '“That photo of Grandma at the lake… the summer we went, I think.”';
  const n = Math.floor(cl((t - 1.6) / 3) * q.length);
  const listen = win(t, 1.4, 5.4, 0.5, 0.5), beam = win(t, 5, 7, 0.4, 0.8);
  const fly = MOTION.move(t, 6, 1.4), shift = MOTION.move(t, 6.2, 1.2);
  const ox = lerp(960, 640, shift), oy = 440;
  const far = [[160, 160, 'doc'], [1760, 180, 'voice'], [140, 900, 'folder'], [1780, 880, 'note'], [1650, 560, 'photo'], [300, 560, 'doc']];
  return (
    <div style={FULL}>
      {far.map(([x, y, k], i) => {
        const found = i === 4;
        const fx = found ? lerp(x, 1330, fly) : x, fy = found ? lerp(y, 470, fly) : y;
        return <Mem key={i} kind={k} x={fx} y={fy} s={found ? lerp(0.35, 1.25, fly) : 0.35} rot={found ? lerp(12, -3, fly) : (i - 3) * 6} blur={found ? 6 * (1 - Math.max(beam, fly)) : 6 - beam * 3} op={0.35 + 0.5 * Math.max(beam, found ? fly : 0) - (found ? 0 : 0.2 * fly)} />;
      })}
      <svg width="1920" height="1080" style={{ ...FULL, opacity: beam }}>
        {far.map(([x, y], i) => <line key={i} x1={ox} y1={oy} x2={x} y2={y} stroke={i === 4 ? '#ffd27a' : 'rgba(150,180,255,.45)'} strokeWidth={i === 4 ? 5 : 2} strokeDasharray="10 14" strokeDashoffset={-t * 60} />)}
      </svg>
      {[0, 1, 2].map((i) => {
        const a = (t * 0.8 + i / 3) % 1, r = 150 + a * 260;
        return <div key={i} style={A(ox - r, oy - r, { width: r * 2, height: r * 2, borderRadius: '50%', border: `3px solid rgba(150,180,255,${0.5 * (1 - a) * listen})` })} />;
      })}
      <Orb x={ox} y={oy} size={280 * MOTION.pop(t, 0.2, 1)} spin={t * 40} glow={1 + 0.6 * beam} />
      <div style={A(260, 700, { width: 1400, textAlign: 'center', fontFamily: SERIF, fontStyle: 'italic', fontSize: 60, color: CREAM, opacity: 1 - MOTION.enter(t, 5.2, 0.6), textShadow: '0 4px 30px rgba(5,8,25,.85)' })}>{q.slice(0, n)}</div>
      <div style={A(1330 - 190, 660, { width: 380, padding: '18px 22px', borderRadius: 16, background: '#141a45', border: '3px solid #3a4480', display: 'flex', flexDirection: 'column', gap: 8, opacity: MOTION.enter(t, 7.4), transform: `translateY(${(1 - MOTION.enter(t, 7.4)) * 20}px)` })}>
        <span style={{ fontFamily: UI, fontSize: 26, color: CREAM }}>Lake_Tahoe_Grandma.jpg</span>
        <span style={{ fontFamily: MONO, fontSize: 16, letterSpacing: '.08em', color: '#9aa3c9' }}>JULY 2019 · YOUR GOOGLE PHOTOS</span>
      </div>
      <Cap t={t} a={1.2} b={5} text="Ask in your own words." y={140} size={56} />
      <Cap t={t} a={7.8} b={11.2} text="Hawk brings back the answer — and the actual file behind it." y={870} size={56} />
    </div>
  );
}

// 8 — the promise
function Promise8({ t }) {
  const ang = t * 1.05 - 1.2, depth = Math.sin(ang);
  const hk = { x: 960 + Math.cos(ang) * 540, y: 400 + depth * 110, s: 0.5 + 0.22 * (depth + 1) / 2, flap: Math.sin(t * 6) * 0.35, rot: -Math.cos(ang) * 12 };
  const orb = <Orb key="o" x={960} y={400} size={240 * MOTION.pop(t, 0, 0.9)} spin={t * 30} glow={1.1} />;
  const hawk = <Hawk key="h" {...hk} op={MOTION.enter(t, 0.3)} />;
  return (
    <div style={FULL}>
      {depth < 0 ? [hawk, orb] : [orb, hawk]}
      <Cap t={t} a={1} b={7.2} text="You remember it." y={700} size={84} />
      <Cap t={t} a={2.6} b={7.2} em="Hawk" text="helps you see it." y={810} size={84} />
    </div>
  );
}

// 9 — close; fades to the opening frame
function Close({ t, end }) {
  const fin = 1 - MOTION.enter(t, end - 1.1, 1);
  const logo = MOTION.enter(t, 4.4, 1);
  return (
    <div style={{ ...FULL, opacity: fin }}>
      <div style={{ ...FULL, background: 'radial-gradient(ellipse 55% 50% at 50% 50%, rgba(255,190,120,.16), rgba(11,16,48,0) 70%)' }} />
      {KINDS.slice(0, 6).map((k, i) => {
        const a = (i / 6) * 6.283 + t * 0.15, r = lerp(620, 430, MOTION.move(t, 0, 4));
        return <Mem key={i} kind={k} x={960 + Math.cos(a) * r * 1.3} y={500 + Math.sin(a) * r * 0.75} s={0.55} rot={Math.sin(a) * 8} op={0.9 * MOTION.enter(t, 0.2 + i * 0.12) * (1 - logo * 0.5)} />;
      })}
      <Cap t={t} a={0.6} b={4.4} text="To make the memories you already have feel close again." y={450} size={80} />
      <div style={A(0, 360, { width: 1920, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20, opacity: logo })}>
        <div style={{ position: 'relative', width: 150, height: 150 }}><Orb x={75} y={75} size={150} spin={t * 30} /></div>
        <span style={{ fontFamily: SERIF, fontSize: 150, lineHeight: 1, color: CREAM, letterSpacing: '-.03em' }}>Hawk</span>
        <span style={{ fontFamily: UI, fontSize: 30, color: '#c3c9e6' }}>You remember it. Hawk helps you see it.</span>
      </div>
    </div>
  );
}

const SCENES = { Lost, Remember, Born, Vision, Private, Words, Ask, Promise: Promise8, Close };
function Piece() {
  const { T, CUES, authoredTotal } = useComposition();
  const names = Object.keys(SCENES);
  return (
    <div style={{ ...FULL, background: NAVY, overflow: 'hidden' }}>
      <Stars T={T} />
      {names.map((nm, i) => {
        const a = CUES[nm] ?? 0, b = i < names.length - 1 ? CUES[names[i + 1]] : authoredTotal;
        if (T < a - 0.5 || T > b + 0.5) return null;
        const S = SCENES[nm];
        const op = i === 0 ? 1 - ei(cl((T - (b - 0.5)) / 1)) : i === names.length - 1 ? MOTION.enter(T, a - 0.5, 1) : win(T, a - 0.5, b + 0.5, 1, 1);
        return <div key={nm} style={{ ...FULL, opacity: op }}><S t={T - a} end={b - a} /></div>;
      })}
    </div>
  );
}

function HawkStory() {
  return (
    <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={NAVY}>
      <Piece />
    </CompositionStage>
  );
}
window.HawkStory = HawkStory;
